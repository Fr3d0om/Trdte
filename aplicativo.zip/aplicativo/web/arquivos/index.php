<?php
$nome = "Fatality";
$foto = "https://i.imgur.com/8PbXhg2.jpg";
$rank = "Deus";
$checker = "Mercado Livre";

?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, CHARSET=UTF-8">
    <title>[ MERCADOLIVRE -  ]</title>

    <!-- Vendor styles -->
    <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
    <link rel="icon" href="https://cours-informatique-gratuit.fr/wp-content/uploads/2014/05/icone-ordinateur.png">
    <link rel="stylesheet" href="vendors/bower_components/material-design-iconic-font/dist/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="vendors/bower_components/animate.css/animate.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
    <input type="hidden" name="socks" id="socks" value="183.166.68.254">
    <input type="hidden" name="sock_die" id="sock_die" value="183.166.68.254">
    <input type="hidden" name="sock_ruim" id="sock_ruim" value="183.166.68.254">
    <input type="hidden" name="socks" id="socks" value="183.166.68.254">
    <input type="hidden" name="countsock" id="countsock" value="0">

        <!-- App styles -->
        <link rel="stylesheet" href="css/app.min.css">
        <style>body{font-family: 'ubuntu', sans-serif;}</style>
<script>
var myVar=setInterval(function(){myTimer()},1000);
function myTimer() {
    var d = new Date();
    document.getElementById("demo").innerHTML = d.toLocaleTimeString();
}
</script>
<script type="text/javascript">
function Mudarestado(el) {
        var display = document.getElementById(el).style.display;
        if(display == "none")
            document.getElementById(el).style.display = 'block';
        else
            document.getElementById(el).style.display = 'none';
    }
</script>

    </head>

    <body data-sa-theme="4">


<br><br><br>



<center>


<div class="card-demo animated tada">
<div class="card" style="width:90%;">
<div class="card-header">STATUS : <code><span id="status">AGUARDANDO COMANDO</span></code> - Testado: <code>[ <span id="testado" class="label label-info">0</span> ]</code> - Total: <code>[ <span id="tudo_conta" class="label label-default">0</span> ]</code></div>
<div class="card-body">

<!-- APROVADAS --> 
<div class="card-demo" style="width:55%;float:left;">
<div class="card">
<div class="card-header">Aprovadas <code>[ <span class="label label-success aprovada_conta">0</span> ]</code></div>                            
<div class="card-body">
<div class="card-text" id="aprovadas"></div>
</div>
</div>
</div>
<!-- APROVADAS C VERIF -->
<div class="card-demo" style="width:55%;float:left;">
<div class="card">
<div class="card-header">Aprovadas C/ Verificação<code>[ <span class="label label-success aprovada_conta_v">0</span> ]</code></div>                            
<div class="card-body">
<div class="card-text" id="aprovadas_v"></div>
</div>
</div> 
</div>
<!-- REPROVADAS -->
<div class="card-demo" style="width:55%;float:left;">
<div class="card">
<div class="card-header">Reprovadas <code>[ <span class="label label-danger reprovada_conta">0</span> ]</code> -- <button onclick="Mudarestado('card-body')" class="btn btn-light btn--icon-text">OCULTAR</button></div>                            
<div class="card-body" id="card-body">
<div class="card-text" id="reprovadas"></div>
</div>
</div> 
</div>
<!-- REPROVADAS -->
<div class="card-demo" style="width:55%;float:left;">
<div class="card">
<div class="card-header">[Configurações]</div> 
<label class="label label-danger">[Enviar Saldo]</label>
<input type="radio" name="enviar_saldo" value="sim" checked><label>[Sim]</label>
<input type="radio" name="enviar_saldo" value="nao" ><label>[Não]</label>
<input class="form-control" aria-label="Small" type="text" name="email_saldo" id="email_saldo" placeholder="Email do Mercado Pago">
<div class="card-body" id="card-body">
</div>
</div> 
</div>
<!-- INFOS -->
<div class="card-demo">
<div class="card" style="width:40%;">
<div class="card-header">Menu</div>
<div class="card-body"><br>
<img class="img-circle" style="width:100px;height:100px;border-radius:50px;" src="<?php echo $foto; ?>"><br><br>
<p>Usuario: <code><?php echo $nome; ?></code>
<p>Rank: <code><?php echo $rank ?></code>
<p>Horário: <code><span id="demo">00:00:00</span></code></p>
<p>Checker Em Execução: <code><?php echo $checker ?></code>
<br><br>

Lista
<textarea class="form-control" id="lista" name="lista" placeholder="email@mercadolivre.com|123456" style="width:60%;height:100px;text-align:center;"></textarea><br>

<button class="btn btn-light btn--icon-text" id="iniciar"><i class="zmdi zmdi-play"></i> Iniciar</button> <button class="btn btn-light btn--icon-text" id="parar"><i class="zmdi zmdi-stop"></i> Pausar</button>

</div>
</div>
</div>

</div>
</div>
</div>

</center>

<br>

        <!-- Javascript -->
        <script src="jquery.min.js"></script>
        <script src="jquery-ui.js"></script>
        <script src="accman.js"></script>
    </body>
</html>