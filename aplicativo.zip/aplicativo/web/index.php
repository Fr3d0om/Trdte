
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Home - Dashboard</title>

  <!-- Vendor styles -->
  <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
  <link rel="icon" href="https://cdn.discordapp.com/attachments/669235430025199657/697785923143991367/latest.png">
  <link rel="stylesheet" href="vendors/bower_components/material-design-iconic-font/dist/css/material-design-iconic-font.min.css">
  <link rel="stylesheet" href="vendors/bower_components/animate.css/animate.min.css">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">

  <!-- App styles -->
  <link rel="stylesheet" href="css/app.min.css">
  <style>body{font-family: 'ubuntu', sans-serif;}
  .lista-retornos{
    float: left;
  }</style>
  <script type="text/javascript">
    function Mudarestado(el) {
      var display = document.getElementById(el).style.display;
      if(display == "none")
        document.getElementById(el).style.display = 'block';
      else
        document.getElementById(el).style.display = 'none';
    }
  </script>

  <br><br>

  <body data-sa-theme="4">

    <center>

     <div class="card-body"><br>
    <img class="img-circle" style="width:130px;height:100px;border-radius:50px;" src="kaoru.jpg" alt="Kaoruoo"><br><br>
</div>


    </div>
    <p>Checker Em Execução: <code>VISA/MASTER</code><br><br>


      <div class="card-demo animated tada">

        <div class="card-body">

          <div id="BodyOfTheNotifications">








          </div>
          <a class="dropdown-item text-center small text-gray-500" href=""></a>
        </div>
      </li>

      <div class="topbar-divider d-none d-sm-block"></div>

      <!-- Nav Item - User Information -->
    </span> 𝐓𝐨𝐭𝐚𝐥 : <span id="total" class="badge badge-info">0</span> <font class="text-gray-800"><b>Status: </b><span id="status" class=""></span>
    </nav>
    <div class="container-fluid">
      <center><h1 class="h3 mb-0 text-gray-800"></h1></center>
      <br>
      <center>
        <textarea placeholder="FORMATO: XXXXXXXXXXXXXXX|XX|XXXX|XXX" id="list" class="form-control" style="width:70%;height:100px;text-align:center;" maxlength="8699"></textarea><br>

        <br>




        <div class="button-list">
          <button class="btn btn-light btn--icon-text" type="submit" id="start"><i class="fas fa-play"></i>&nbsp;Iniciar</button>
          <button class="btn btn-light btn--icon-text" type="submit" id="stop"><i class="fas fa-pause"></i>&nbsp;Pausar</i></button>
          <button class="btn btn-light btn--icon-text" type="clear" id="clear"><i class="far fa-trash-alt"></i>&nbsp;Limpar</i></button>
        </div>
        <br/>
      </center>
      <center>
        <div class="col-md-12">
          <ul class="nav nav-tabs md-tabs" role="tablist">
            <li class="nav-item">
              <span id="live" class="badge badge-success">0</span>
              <a class="nav-link active" data-toggle="tab" href="#aprovadasresult" role="tab" aria-expanded="true"><label class="btn-outline-success" id="live">APROVADAS</label></a>
              <div class="slide"></div>
            </li>
            <li class="nav-item">
              <span id="die" class="badge badge-danger">0</span>
              <a class="nav-link" data-toggle="tab" href="#reprovadasresult" role="tab" aria-expanded="false"><label  id="die" class="btn-outline-danger">REPROVADAS</label></a>
            </div>
            <div class="slide"></div>
          </li>
        </ul>            
        <div class="tab-content card-block">
          <div class="tab-pane active" id="aprovadasresult" role="tabpanel" aria-expanded="true">
            <div class="table-responsive">
              <table class="table">
                <thead>
                </thead>
                <tbody id="aprovadas">
                </tbody>
              </table>
            </div>
          </div>
          <div class="tab-pane" id="reprovadasresult" role="tabpanel" aria-expanded="false">
            <div class="table-responsive">
              <table class="table">
                <thead>
                </thead>
                <tbody id="reprovadas">
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /.container-fluid -->
    <!-- Footer -->
    <footer class="sticky-footer bg-white">
      <div class="container my-auto">
        <div class="copyright text-center my-auto">
        </div>
      </div>
    </footer>
    <!-- End of Footer -->

  </div>
  <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
  <i class="fas fa-angle-up"></i>
</a>

<!-- Logout Modal-->

<!-- Bootstrap core JavaScript-->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.js" type="text/javascript"></script>
<script type="text/javascript">
  <script src="vendor/jquery/jquery.min.js"
  </script>
  <script src="vendor/jquery/GenerateKey.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/chart-area-demo.js"></script>
  <script src="js/demo/chart-pie-demo.js"></script>
  <script>
    var audio = new Audio('blop.mp3');
    $(document).ready(function () {
      LIST_MESSAGES();
      Quant();
      function LIST_MESSAGES()
      {
        $.ajax({
          url:"ListMessages.php",
          method:"POST",
          success:function(data){
            $('#BodyOfTheNotifications').html(data);
          }
        })
      }

      function Quant()
      {
        $.ajax({
          url:"ListNumberNotify.php",
          method:"POST",
          success:function(data){
            $('#QuantNotify').html(data);
          }
        })
      }
      $('#status').html('<span id="bad" class="class=" btn-outline-warning">Não iniciado <i class="fas fa-exclamation-circle"></i></span>');
      $('#start').attr('disabled', null);
      $('#clear').attr('disabled','disabled');
      $('#stop').attr('disabled','disabled');
      $('#start').click(function () {
        audio.play();
        var line = $('#list').val().split('\n');
        var total = line.length;
        var ap = 0;
        var rp = 0;
        var sd = 0;
        $('#total').html(total);
        line.forEach(function (value,) {
          var ajaxCall = $.ajax({
            url: 'chk.php?lista=' + value,
            type: 'GET',
            data: 'linhas=' + value,
            beforeSend: function () {
              $('#status').html('<span class=" btn-outline-primary">Testando !</span>');
              $('#stop').attr('disabled',null);
              $('#stop').attr('disabled',null);
              $('#start').attr('disabled','disabled');
            },


            success: function(data){
              if(data.indexOf("Aprovada") >= 0){
                $("#aprovadas").val(data + "\n" + $("#aprovadas").val());
                ap = ap + 1;
                document.getElementById("aprovadas").innerHTML += data + "<br>";
                audio.play();
                removelinha();
              }else{
                $("#reprovadas").val(data + "\n" + $("#reprovadas").val());
                rp = rp + 1;
                document.getElementById("reprovadas").innerHTML += data + "<br>";
                removelinha();
              }
              var fila = parseInt(ap) + parseInt(rp);
              $('#live').html(ap);
              $('#die').html(rp);
              $('#testadas').html(fila);
              if (fila == total) {
                $('#start').attr('disabled', null);
                $('#stop').attr('disabled', 'disabled');
                $('#clear').attr('disabled',null);
                $('#status').html('<span class=" btn-outline-secondary">Teste Finalizado !</span>');
                audio.play();
              }
            }
          });
          $('#stop').click(function(){
            ajaxCall.abort();
            $('#start').attr('disabled',null);
            $('#stop').attr('disabled','disabled');
            $('#clear').attr('disabled',null);
          });
        });
        $('#stop').click(function(){
          $('#status').html('<span class=" btn-outline-danger">Parado !</span>');

        });

        $('#clear').click(function(){
          $('#status').html('<span class=" btn-outline-info">Lista Limpa!</span>');
          $('#list').val('');
        });
      });
    });
    function removelinha() {
      var lines = $("#list").val().split('\n');
      lines.splice(0, 1);
      $("#list").val(lines.join("\n"));
    }


  </script>
</body>

</head>
</center>


<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.5.11/js/mdb.min.js"></script>
<script src="arquivos/jquery.min.js"></script>
<script src="arquivos/jquery-ui.js"></script>
<script src="arquivos/action.js"></script>
<script src="arquivos/bootstrap.min.js"></script>

</body>
</html>